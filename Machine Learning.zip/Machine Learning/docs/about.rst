About us
========


Core Development Team
---------------------

Yue Zhao (initialized the project in 2017): `Homepage <https://http://www.andrew.cmu.edu/user/yuezhao2>`_

Zain Nasrullah (joined in 2018):
`LinkedIn (Zain Nasrullah) <https://www.linkedin.com/in/zain-nasrullah-097a2b85>`_

Winston (Zheng) Li (joined in 2018):
`LinkedIn (Winston Li) <https://www.linkedin.com/in/winstonl>`_

Yahya Almardeny (joined in 2019):
`LinkedIn (Yahya Almardeny) <https://www.linkedin.com/in/yahya-almardeny/>`_

